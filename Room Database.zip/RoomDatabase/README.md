# RoomDatabase

## This repo shows real world usage of local storage in Android -  "Room Database" and "Data Store"

<p float="left">
<img src="https://user-images.githubusercontent.com/39574228/128174695-1fee8529-b56d-4ad8-871f-8cd905f7a2a4.png" width="360">
</p>

We store the user information inputted above to Room Database and persist with Data Store

## Full Article

https://proandroiddev.com/save-data-on-android-using-room-database-beginners-guide-1398dafabb24


## CONTACT ME
https://linktr.ee/Ibrajix
